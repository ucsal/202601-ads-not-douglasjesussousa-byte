package br.com.ucsal.olimpiadas;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class App {

    static long proximoParticipanteId = 1;
    static long proximaProvaId = 1;
    static long proximaQuestaoId = 1;
    static long proximaTentativaId = 1;

    static final List<Participante> participantes = new ArrayList<>();
    static final List<Prova> provas = new ArrayList<>();
    static final List<Questao> questoes = new ArrayList<>();
    static final List<Tentativa> tentativas = new ArrayList<>();

    private static final Scanner in = new Scanner(System.in);

    public static void main(String[] args) {
        seed();
        runMenu();
    }

    private static void runMenu() {
        while (true) {
            displayMenu();
            String option = in.nextLine();
            handleMenuOption(option);
        }
    }

    private static void displayMenu() {
        System.out.println("\n=== OLIMPÍADA DE QUESTÕES (V1) ===");
        System.out.println("1) Cadastrar participante");
        System.out.println("2) Cadastrar prova");
        System.out.println("3) Cadastrar questão (A–E) em uma prova");
        System.out.println("4) Aplicar prova (selecionar participante + prova)");
        System.out.println("5) Listar tentativas (resumo)");
        System.out.println("0) Sair");
        System.out.print("> ");
    }

    private static void handleMenuOption(String option) {
        switch (option) {
            case "1" -> cadastrarParticipante();
            case "2" -> cadastrarProva();
            case "3" -> cadastrarQuestao();
            case "4" -> aplicarProva();
            case "5" -> listarTentativas();
            case "0" -> {
                System.out.println("tchau");
                System.exit(0);
            }
            default -> System.out.println("opção inválida");
        }
    }

    private static void seed() {
        Prova prova = new Prova();
        prova.setId(proximaProvaId++);
        prova.setTitulo("Olimpíada 2026 • Nível 1 • Prova A");
        provas.add(prova);

        Questao q1 = new Questao();
        q1.setId(proximaQuestaoId++);
        q1.setProvaId(prova.getId());
        q1.setEnunciado("""
                Questão 1 — Mate em 1.
                É a vez das brancas.
                Encontre o lance que dá mate imediatamente.
                """);
        q1.setFenInicial("6k1/5ppp/8/8/8/7Q/6PP/6K1 w - - 0 1");
        q1.setAlternativas(new String[]{"A) Qh7#", "B) Qf5#", "C) Qc8#", "D) Qh8#", "E) Qe6#"});
        q1.setAlternativaCorreta('C');

        questoes.add(q1);
    }

    private static void cadastrarParticipante() {
        System.out.print("Nome: ");
        var nome = in.nextLine();
        System.out.print("Email (opcional): ");
        var email = in.nextLine();

        if (nome == null || nome.isBlank()) {
            System.out.println("nome inválido");
            return;
        }

        var p = new Participante();
        p.setId(proximoParticipanteId++);
        p.setNome(nome);
        p.setEmail(email);
        participantes.add(p);
        System.out.println("Participante cadastrado: " + p.getId());
    }

    private static void cadastrarProva() {
        System.out.print("Título da prova: ");
        var titulo = in.nextLine();
        if (titulo == null || titulo.isBlank()) {
            System.out.println("título inválido");
            return;
        }

        var prova = new Prova();
        prova.setId(proximaProvaId++);
        prova.setTitulo(titulo);
        provas.add(prova);
        System.out.println("Prova criada: " + prova.getId());
    }

    private static void cadastrarQuestao() {
        if (provas.isEmpty()) {
            System.out.println("não há provas cadastradas");
            return;
        }

        var provaId = escolherProva();
        if (provaId == null) return;

        System.out.println("Enunciado:");
        var enunciado = in.nextLine();
        var alternativas = new String[5];
        for (int i = 0; i < 5; i++) {
            char letra = (char) ('A' + i);
            System.out.print("Alternativa " + letra + ": ");
            alternativas[i] = letra + ") " + in.nextLine();
        }

        System.out.print("Alternativa correta (A–E): ");
        char correta;
        try {
            correta = Questao.normalizar(in.nextLine().trim().charAt(0));
        } catch (Exception e) {
            System.out.println("alternativa inválida");
            return;
        }

        var q = new Questao();
        q.setId(proximaQuestaoId++);
        q.setProvaId(provaId);
        q.setEnunciado(enunciado);
        q.setAlternativas(alternativas);
        q.setAlternativaCorreta(correta);
        questoes.add(q);
        System.out.println("Questão cadastrada: " + q.getId() + " (na prova " + provaId + ")");
    }

    private static void aplicarProva() {
        // Lógica de aplicação da prova
    }

    private static void listarTentativas() {
        // Lógica de listagem de tentativas
    }

    private static Long escolherProva() {
        // Lógica de escolha de prova
    }
}