package br.com.ucsal.olimpiadas;

/**
 * Representa a entidade Participante.
 * Mantendo o SRP: Esta classe foca apenas em representar o modelo de dados.
 */
public class Participante {
    private Long id; // Mudei para Long por boa prática de objetos
    private String nome;
    private String email;

    // Construtor vazio, necessário para persistência em alguns casos
    public Participante() {
    }

    // Construtor facilita a criação do objeto no código
    public Participante(Long id, String nome, String email) {
        this.id = id;
        this.nome = nome;
        this.email = email;
    }

    // Getters e Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
