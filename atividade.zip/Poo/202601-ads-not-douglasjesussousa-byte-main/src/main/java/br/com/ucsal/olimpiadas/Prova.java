package br.com.ucsal.olimpiadas;

/**
 * Representa a entidade Prova.
 * Segue o SRP ao manter apenas dados referentes à estrutura de uma prova.
 */
public class Prova {

    private Long id;
    private String titulo;

    // Construtor padrão
    public Prova() {
    }

    // Construtor por conveniência
    public Prova(Long id, String titulo) {
        this.id = id;
        this.titulo = titulo;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
}
