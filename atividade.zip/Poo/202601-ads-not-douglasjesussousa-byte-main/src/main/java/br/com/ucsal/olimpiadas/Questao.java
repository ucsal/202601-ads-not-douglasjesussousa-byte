package br.com.ucsal.olimpiadas;

import java.util.Arrays;

/**
 * Refatoração focada em SRP. 
 * As regras de validação foram isoladas para garantir que a classe 
 * represente apenas o estado de uma Questão.
 */
public class Questao {

    private Long id;
    private Long provaId;
    private String enunciado;
    private String[] alternativas = new String[5];
    private char alternativaCorreta;

    // Construtor padrão
    public Questao() {}

    public boolean isRespostaCorreta(char marcada) {
        return normalizar(marcada) == alternativaCorreta;
    }

    private char normalizar(char c) {
        char up = Character.toUpperCase(c);
        if (up < 'A' || up > 'E') {
            throw new IllegalArgumentException("Alternativa inválida: " + c);
        }
        return up;
    }

    // Getters e Setters simplificados
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getProvaId() { return provaId; }
    public void setProvaId(Long provaId) { this.provaId = provaId; }

    public String getEnunciado() { return enunciado; }
    public void setEnunciado(String enunciado) { this.enunciado = enunciado; }

    public String[] getAlternativas() { return alternativas; }
    
    public void setAlternativas(String[] alternativas) {
        if (alternativas == null || alternativas.length != 5) {
            throw new IllegalArgumentException("Devem ser 5 alternativas.");
        }
        this.alternativas = Arrays.copyOf(alternativas, 5);
    }

    public char getAlternativaCorreta() { return alternativaCorreta; }
    
    public void setAlternativaCorreta(char alternativaCorreta) {
        this.alternativaCorreta = normalizar(alternativaCorreta);
    }
}