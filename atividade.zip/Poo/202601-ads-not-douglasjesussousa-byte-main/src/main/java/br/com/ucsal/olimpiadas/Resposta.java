package br.com.ucsal.olimpiadas;

/**
 * Representa a resposta dada por um participante a uma questão.
 * Responsável apenas por armazenar o vínculo entre o ID da questão e a opção marcada.
 */
public class Resposta {

    private Long questaoId;
    private char alternativaMarcada;
    private boolean correta;

    public Resposta() {
    }

    public Resposta(Long questaoId, char alternativaMarcada) {
        this.questaoId = questaoId;
        this.alternativaMarcada = Character.toUpperCase(alternativaMarcada);
    }

    // A lógica de decidir se está correta pode vir da Questao,
    // mas a Resposta armazena o resultado dessa avaliação.
    public void avaliar(Questao questao) {
        if (questao.getId().equals(this.questaoId)) {
            this.correta = questao.isRespostaCorreta(this.alternativaMarcada);
        }
    }

    public Long getQuestaoId() {
        return questaoId;
    }

    public void setQuestaoId(Long questaoId) {
        this.questaoId = questaoId;
    }

    public char getAlternativaMarcada() {
        return alternativaMarcada;
    }

    public void setAlternativaMarcada(char alternativaMarcada) {
        this.alternativaMarcada = Character.toUpperCase(alternativaMarcada);
    }

    public boolean isCorreta() {
        return correta;
    }
    
    // Removendo o setCorreta público para evitar que o valor seja alterado 
    
}