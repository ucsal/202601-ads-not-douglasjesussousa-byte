package br.com.ucsal.olimpiadas;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Representa a tentativa de um participante em uma prova.
 * SRP: Gerencia o vínculo entre participante, prova e o conjunto de respostas.
 */
public class Tentativa {

    private Long id;
    private Long participanteId;
    private Long provaId;
    private final List<Resposta> respostas = new ArrayList<>();

    public Tentativa() {
    }

    public Tentativa(Long id, Long participanteId, Long provaId) {
        this.id = id;
        this.participanteId = participanteId;
        this.provaId = provaId;
    }

    /**
     * Adiciona uma resposta na tentativa.
     * Centraliza a lógica para evitar inconsistências.
     */
    public void adicionarResposta(Resposta resposta) {
        // Poderia haver uma validação aqui para não repetir questaoId
        this.respostas.add(resposta);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getParticipanteId() {
        return participanteId;
    }

    public void setParticipanteId(Long participanteId) {
        this.participanteId = participanteId;
    }

    public Long getProvaId() {
        return provaId;
    }

    public void setProvaId(Long provaId) {
        this.provaId = provaId;
    }

    /**
     * Retorna uma lista não modificável 
     */
    public List<Resposta> getRespostas() {
        return Collections.unmodifiableList(respostas);
    }
}